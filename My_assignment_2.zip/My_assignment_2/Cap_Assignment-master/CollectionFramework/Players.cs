﻿using System;

namespace CollectionFramework
{
    public class Players
    {
        public String _name;
        public int _runScored;
        public Players(String name, int runs)
        {
            _name = name;
            _runScored = runs;
        }
    }
}
