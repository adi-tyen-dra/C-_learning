﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileIOMethods
{
    internal class MainMethod
    {
        public static void Main()
        {
            DirectoryInfoProperties dinfo=new DirectoryInfoProperties();
            DirectoryProperties dp = new DirectoryProperties();
            FileInfoProperties fileinfo=new FileInfoProperties();
            FilePropertiess file=new FilePropertiess();
        }
    }
}
