﻿using System;

namespace LitwareLib
{
    internal interface IPrintable
    {
        void ShowDetails();
    }
}
