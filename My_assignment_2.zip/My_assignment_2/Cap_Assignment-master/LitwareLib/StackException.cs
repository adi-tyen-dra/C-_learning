﻿using System;

namespace LitwareLib
{
    internal class StackException:Exception
    {
        public StackException(String message) : base(message)
        { }
    }
}
